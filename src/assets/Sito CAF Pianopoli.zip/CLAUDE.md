# Progetto: Sito CAF FAPI – Sede di Pianopoli

## Brand
- Nome principale: **FAPI – Sede di Pianopoli** (monogramma "F" navy/oro).
- **Punto Semplice** = piattaforma dei servizi digitali (SPID, PEC, Firma Digitale), NON il brand principale.
- Altre piattaforme/partner: Patronato ENAC, APS Senza Nodi, Credipass, RentalSi, Semplicert, Amazon Hub, Pronto Pacco, Indabox, Promoterbet, Caf Energia e Gas.

## Palette (dalle locandine)
- Navy primario #101f4f / profondo #0b1638
- Azzurro #3b74d6, azzurro chiaro #5a8ee0
- Oro/giallo #e0a02a / #f0b83f
- Teal #1f9d8f, indaco #3a4d9e
- (magenta/viola Punto Semplice usati con parsimonia)

## Font
- Home attuale usa **Plus Jakarta Sans** (F1). Alternative mostrate: Libre Franklin, Sora, Manrope. Da confermare.

## Contatti
- Indirizzo: Via Roma 69, 88040 Pianopoli (CZ)
- Tel: 377 960 9155
- Email: agenziatodaro@gmail.com · infofacciamotuttonoi@gmail.com · pianopolicaf@gmail.com
- Orari: Lun–Ven 9–13 / 15:30–18:30

## Scope
Sito pubblico completo + area utente (login/registrazione, documenti con stato, scadenze con promemoria, appuntamenti) + pannello admin (clienti, pratiche/stati, scadenze dashboard, appuntamenti, statistiche). Lingua IT + EN. Animazioni molto dinamiche.

## 6 macro-aree servizi
1. Fiscale & Sociale (CAF Fapi, Patronato ENAC, APS Senza Nodi, ISEE)
2. Innovazione Digitale (Punto Semplice: SPID/PEC/Firma, segreteria, consulenza auto)
3. Pagamenti & Energia (Semplicert, Caf Energia e Gas, bonus)
4. Credito & Mobilità (Credipass, RentalSi)
5. Logistica & Ritiri (Amazon Hub, Pronto Pacco, Indabox)
6. Ricariche & Gift Card (Promoterbet)
